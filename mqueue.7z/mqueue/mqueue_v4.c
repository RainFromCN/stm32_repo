#include "mqueue_v4.h"


/* ������Ϣ���� */
MessageQueue_TypeDef MQUEUE_Open(UART_HandleTypeDef* mq_uart) {
    
    MessageQueue_TypeDef tmp;

    tmp.mq_uart = mq_uart;
    HAL_UART_Receive_IT(tmp.mq_uart, &tmp->buff, 1);

    return tmp;
}

/* ������Ϣ���� */
void MQUEUE_Update(UART_HandleTypeDef* huart, MessageQueue_TypeDef* M) {
    
    if (M->mq_uart != huart) {
        HAL_UART_Receive_IT(M->mq_uart, &M->buff, 1);
        return;
    }

    /* ���յ�֡ͷ */
    if (M->buff == '@') {
        M->topic_len = 0;
        M->value_len = 0;
        M->mark = 0;
        M->cx = 0;
    }

    /* ���յ������ */
    else if (M->buff == '#') {
        M->mark = 1;
    }

    /* ���յ��ָ��� */
    else if (M->buff == '$') {
        M->mark = 2;
    }

    /* ���յ������� */
    else if (M->buff == '%') {

        /* У��λ��ȷ */
        if (M->cx == M->cx_rec) {

            M->topic[M->topic_len++] = '\0';

            /* ��ֵ */
            for (uint8_t i = 0; i < queue_size; i++) {

                if (strcmp((M->message[i]).topic, M->topic) == 0) {
                    if ((M->message[i]).data_type == MQUEUE_FLOAT) {
                        *(float*)(M->message[i]).to = *(float*)M->value;
                    }
                    else if ((M->message[i]).data_type == MQUEUE_INT) {
                        *(int*)(M->message[i]).to = *(int*)M->value;
                    }
                }
            }
        }

        /* ���� */
        M->topic_len = 0;
        M->value_len = 0;
        M->mark = 0;
        M->cx = 0;
    }

    /* ���յ�topic */
    else if (M->mark == 0) {

        /* ���������� */
        if (M->topic_len == 20) {
            M->topic_len = 0;
            M->value_len = 0;
            M->mark = 0;
            M->cx = 0;
        }

        M->cx += M->buff;
        M->topic[M->topic_len++] = M->buff;
    }

    /* ���յ�value */
    else if (M->mark == 1) {

        /* ���������� */
        if (M->value_len == 4) {
            M->topic_len = 0;
            M->value_len = 0;
            M->mark = 0;
            M->cx = 0;
        }

        M->cx += M->buff;
        M->value[M->value_len++] = M->buff;
    }

    /* ���յ�cx */
    else if (M->mark == 2) {
        M->cx_rec = M->buff;
    }

    HAL_UART_Receive_IT(M->mq_uart, &M->buff, 1);
}

/* ����һ������ */
void MQUEUE_Subscribe(MessageQueue_TypeDef* M, char* topic, uint32_t* to, uint8_t data_type) {
    Message_TypeDef tmp;

    strcpy(tmp->topic, topic);
    tmp.to = to;
    tmp.data_type = data_type;

    M->message[M->queue_size++] = tmp;
}

/* ����һ������ */
void MQUEUE_Publish(UART_HandleTypeDef* huart, char* topic, uint32_t* from) {
    
    char head = '@';
    char div1 = '#';
    char div2 = '$';
    char end  = '%';
    uint8_t cx;
    uint8_t* p = (uint8_t*)from;

    HAL_UART_Transmit(huart, &head, 1, 0xffff);
    HAL_UART_Transmit(huart, topic, strlen(topic), 0xffff);
    HAL_UART_Transmit(huart, &div1, 1, 0xffff);
    HAL_UART_Tramsmit(huart, (uint8_t*)from, 4, 0xffff);
    HAL_UART_Transmit(huart, &div2, 1, 0xffff);

    for (uint8_t i = 0; topic[i] != '\0'; i++) cx += topic[i];
    for (uint8_t i = 0; i < 4; i++) cx += p[i];

    HAL_UART_Transmit(huart, &cx, 1, 0xffff);
    HAL_UART_Transmit(huart, &end, 1, 0xffff);
}